package defect;

public interface Maneuverable {
    void executeManeuver(); // Fixed method name case and removed private field
}