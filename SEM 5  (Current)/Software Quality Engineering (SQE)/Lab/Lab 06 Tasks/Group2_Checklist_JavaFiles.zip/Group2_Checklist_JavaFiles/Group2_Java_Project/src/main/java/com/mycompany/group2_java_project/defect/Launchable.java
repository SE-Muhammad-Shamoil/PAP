package defect;

public interface Launchable {
    void launch(); // Uncommented to define the contract
}