package defect;

public interface Communicable {
    void transmitData(String payload);
}