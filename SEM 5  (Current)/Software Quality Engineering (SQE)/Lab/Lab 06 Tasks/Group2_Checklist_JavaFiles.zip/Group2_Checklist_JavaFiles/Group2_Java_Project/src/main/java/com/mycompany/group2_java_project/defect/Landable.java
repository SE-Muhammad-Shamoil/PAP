package defect;

public interface Landable {
    void land(); // Added method to define the contract
}